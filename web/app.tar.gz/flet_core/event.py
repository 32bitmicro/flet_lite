class Event:
    def __init__(self, target: str, name: str, data: str):
        self.target: str = target
        self.name: str = name
        self.data: str = data
