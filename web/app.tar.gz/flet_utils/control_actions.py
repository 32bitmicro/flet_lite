

all_control_actions = {
    "TextField" : ["on_change", "on_submit", "on_focus", "on_blur"]
}