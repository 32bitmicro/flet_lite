




def manage_route_request (route_name:str, main_class):
    main_class.page.go(route_name)