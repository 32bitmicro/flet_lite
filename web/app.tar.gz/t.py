class gg:
    def __init__(self) -> None:
        pass


def hia():
    pass

print(hia.__name__)