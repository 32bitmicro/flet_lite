from flet import *


def main (page:Page):
    page.add(Text("Hola!"))


app(target=main)