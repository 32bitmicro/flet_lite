# flet_browser
This is the browser side of communication manager. Helps pyodide to communicate with real python.